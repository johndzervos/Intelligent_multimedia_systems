clc;
clear all;
close all;

path = 'TwoEnterShop3cor\';
all_frames =[];
data=textread('GT.txt');

first_frame_name = [path 'TwoEnterShop3cor' num2str(0,'%04d') '.jpg'];
first_frame = imread(first_frame_name);
aaa=size(first_frame);

figure('Name','First frame: locate the target');
imshow(first_frame,'InitialMagnification','fit');
hold on;

%coords of first frame:
GTcoords=data(1,:);
Nbox=GTcoords(1);
for i=0:Nbox-1
	id=GTcoords(i*5+2);
	h=GTcoords(i*5+3);
	w=GTcoords(i*5+4);
	x=GTcoords(i*5+5);
	y=GTcoords(i*5+6);
	caption2 = sprintf('id: %d',id);
	text('units','pixels','position',[x aaa(2)-y],'string',caption2,'color','r'); 
	plot(x,y,'r.');
	rectangle('Position',[round(x-w/2),round(y-h/2),w,h],'edgecolor','r');
end


f=figure('Name','Locating...');
for next_frame_nr = 1:1148
		caption = sprintf('frame: %d',next_frame_nr);
		set(f,'Name',caption,'NumberTitle','off')
		k=0;
		next_frame_name = [path 'TwoEnterShop3cor' num2str(next_frame_nr,'%04d') '.jpg'];
		current_frame = imread(next_frame_name);
		imshow(current_frame,'InitialMagnification','fit');
		hold on;
		%current_frameD = double(current_frame);
		
		
		%--------------
		%plot rectangles
		GTcoords=data(next_frame_nr+1,:);
		Nbox=GTcoords(1);
		
		for i=0:Nbox-1
			id=GTcoords(i*5+2);
			h=GTcoords(i*5+3);
			w=GTcoords(i*5+4);
			x=GTcoords(i*5+5);
			y=GTcoords(i*5+6);
			caption2 = sprintf('id: %d',id);
			text('units','pixels','position',[x aaa(2)-y],'string',caption2,'color','r'); 
			plot(x,y,'b.');
			rectangle('Position',[round(x-w/2),round(y-h/2),w,h],'edgecolor','b');
		end
		%--------------
		
		%brute force
		%[xc1,yc1] = brute (current_frameD,xc1,yc1,width,height,target1D,mask);
		
		%mean shift
		
		%[xc2a,yc2a,scorea] = meanShift (current_frameD,xc2,yc2,1.1*width,1.1*height,target1D);
		%[xc2b,yc2b,scoreb] = meanShift (current_frameD,xc2,yc2,width,height,target1D);
		%[xc2c,yc2c,scorec] = meanShift (current_frameD,xc2,yc2,0.9*width,0.9*height,target1D);
		
		%results=zeros(3,5);
		%results(1,:)=[xc2a,yc2a,scorea,1.1*width,1.1*height];
		%results(2,:)=[xc2b,yc2b,scoreb,width,height];
		%results(3,:)=[xc2c,yc2c,scorec,0.9*width,0.9*height];
		
		%asdf=min(results(:,3));
		%ind=find(results(:,3)==asdf);
		%best=results(ind,:);
		
		%xc2=best(1);
		%yc2=best(2);
		%width=best(4);
		%height=best(5);
		
		%[xc2,yc2] = brute (current_frameD,xc2,yc2,width,height,target1D,mask);
		
		% if(best(1,1)<90)
			% target3D=test3D;
		% end

		hold on;
		%plot(xc1,yc1,'r*');
		%rectangle('Position',[xc1-width/2,yc1-height/2,width,height],'edgecolor','r');
		
		%plot(xc2,yc2,'b.');
		%rectangle('Position',[xc2-width/2,yc2-height/2,width,height],'edgecolor','b');
		text('units','pixels','position',[10 25],'string',caption,'color','r'); 
		
		all_frames = [all_frames getframe(gca)];
		%close('window');
		prev_frame=current_frame;
		clf;
end

save_movie(all_frames, 'your_movie.avi', 23, 100, 'None');