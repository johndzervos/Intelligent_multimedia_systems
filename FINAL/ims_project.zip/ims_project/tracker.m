clc;
clear all;
close all;
%--------
%path = 'bicycle\';
%first_frame_name = [path 'Samsung Galaxy S II 1080p HD video sample ' num2str(0565,'%04d') '.jpg'];
%--------
%path = 'MoreFrames_part_1\part_1\';
%first_frame_name = [path 'Frame' num2str(85,'%04d') '.png'];
%---------
path = 'TwoEnterShop3cor\';
data=textread('GT.txt');
first_frame_name=[path 'TwoEnterShop3cor' num2str('0265') '.jpg'];
%---------
all_frames =[];
xTRms=[];
yTRms=[];
xTRbf=[];
yTRbf=[];
xGT=[];
yGT=[];

first_frame = imread(first_frame_name);

%first_frame=double(first_frame);
figure('Name','First frame: locate the target');
imshow(first_frame,'InitialMagnification','fit');
hold on;
%---------------------  WE WANT BOX WITH ID=6
aaa=size(first_frame);
%coords of first frame:
GTcoords=data(265,:);
Nbox=GTcoords(1);
for i=0:Nbox-1
	id=GTcoords(i*5+2);
	h=GTcoords(i*5+3);
	w=GTcoords(i*5+4);
	x=GTcoords(i*5+5);
	y=GTcoords(i*5+6);
	if id==2
		caption2 = sprintf('id: %d',id);
		text('units','pixels','position',[x aaa(2)-y],'string',caption2,'color','r'); 
		plot(x,y,'r.');
		
		xTRms=x;
		yTRms=y;
		xTRbf=x;
		yTRbf=y;
		xGT=x;
		yGT=y;
		
		xmin=round(x-w/2);
		xmax=round(x+w/2);
		ymin=round(y-h/2);
		ymax=round(y+h/2);
		rectangle('Position',[round(x-w/2),round(y-h/2),w,h],'edgecolor','r');
		
	end
end
%---------------------

%select with the mouse the target
% [x,y] = ginput(2)
% hold on;
% xmin = floor(min(x));
% xmax = floor(max(x));
% ymin = floor(min(y));
% ymax = floor(max(y));

%coords for football
%xmin=274;
%xmax=294;
%ymin=244;
%ymax=286;

width=floor(xmax-xmin);
height=floor(ymax-ymin);

if(mod(width,2)==0)
	width=width+1;
end

if(mod(height,2)==0)
	height=height+1;
end

%draw a rectangle on the selected coordinates
rectangle('Position',[xmin,ymin,width,height])

%extract target to compute histogram
target=first_frame(ymin:(ymin+height-1),xmin:(xmin+width-1),:);

%target=im2double(target);
figure('Name','target');
imshow(target,[]);

target=double(target);
xx=size(target);

%mask2 = kernel_mask_gaussian(width, height, 3);
mask2 = kernel_mask_epane(width, height, 1);
zz=size(mask2);

%normalise the RGB values of the target
target=normrgb(target);
[ target3D ] = imageHist2(target, 16,mask2);
%[bin_counts1, bin_numbers1] = im_weighted_2D_histogram(16, target, mask)
target1D=reshape(target3D,1,4096);
prev_frame=first_frame;

%calculate the center of the target window
xc=xmin+width/2;
yc=ymin+height/2;

f=figure('Name','Locating...');
%-------
%for next_frame_nr = 85:150
%-------
%for next_frame_nr = 1:1148
for next_frame_nr=265:390
%-------
%for next_frame_nr = 566:713
		
		
		
		caption = sprintf('frame: %d',next_frame_nr);
		set(f,'Name',caption,'NumberTitle','off')
		%------
		%next_frame_name = [path 'Frame' num2str(next_frame_nr,'%04d') '.png'];
        %------
		%next_frame_name = [path 'Samsung Galaxy S II 1080p HD video sample ' num2str(next_frame_nr,'%04d') '.jpg'];
		%------
		next_frame_name = [path 'TwoEnterShop3cor' num2str(next_frame_nr,'%04d') '.jpg'];
		%------
		current_frame = imread(next_frame_name);
		imshow(current_frame,'InitialMagnification','fit');
		current_frameD = double(current_frame);
        %normalise the RGB values of the current frame
        current_frameD=normrgb(current_frameD);
		hold on;
		%--------------
		%plot rectangles
		GTcoords=data(next_frame_nr+1,:);
		Nbox=GTcoords(1);
		
		for i=0:Nbox-1
			id=GTcoords(i*5+2);
			h=GTcoords(i*5+3);
			w=GTcoords(i*5+4);
			x=GTcoords(i*5+5);
			y=GTcoords(i*5+6);
			if id==2
			
				xGT=[xGT x];
				yGT=[yGT y];
			
				caption2 = sprintf('id: %d',id);
				text('units','pixels','position',[x aaa(2)-y],'string',caption2,'color','r'); 
				plot(x,y,'r.');
				rectangle('Position',[round(x-w/2),round(y-h/2),w,h],'edgecolor','r');
			end
		end
		%--------------
		
        		
%-------------------------------brute force
		[xc2,yc2] = brute(current_frameD,xc,yc,width,height,target1D,mask2);
		xTRbf=[xTRbf xc2];
		yTRbf=[yTRbf yc2];
		plot(xc2,yc2,'g.');
		rectangle('Position',[xc2-width/2,yc2-height/2,width,height],'edgecolor','g');

%------------------------- 		%mean shift
%     
        %initialize the parameters of the loop
        dist=1000;
        Nmax=0;
        
        while (Nmax<20 && dist>0.5)
            [xcnew,ycnew,scorenew] = meanShift (current_frameD,xc,yc,width,height,target1D);
            dist=sqrt((xcnew-xc)^2 + (ycnew-yc)^2);
            Nmax=Nmax+1;
            yc=0.5*(ycnew+yc);
            xc=0.5*(xcnew+xc);
        end
        [widthNew,heightNew]=chooseBestScale2(current_frameD,xc,yc,width,height,target1D);
		
		%plot the selected rectangle
        hold on;
		xTRms=[xTRms xc];
		yTRms=[yTRms yc];
		plot(xc,yc,'b.');
		rectangle('Position',[xc-widthNew/2,yc-heightNew/2,widthNew,heightNew],'edgecolor','b');
		text('units','pixels','position',[10 25],'string',caption,'color','r'); 
		
		all_frames = [all_frames getframe(gca)];
		prev_frame=current_frame;
		
		% if next_frame_nr==230
			% pause;
		% end 
		
		% if next_frame_nr==250
			% pause;
		% end 
		
	clf;
end

figure('name','distance from groundtruth')
dd1=sqrt((xTRms-xGT).^2+(yTRms-yGT).^2);
dd2=sqrt((xTRbf-xGT).^2+(yTRbf-yGT).^2);
plot(dd1,'color','blue');
hold on;
plot(dd2,'color','green');
xlabel('Frame');
ylabel('Distance from Groundtruth');
legend('mean-shift','brute force','Location','NorthWest');
 

%save_movie(all_frames, 'tracker_mall_bf_ms_gt_final_experiment3b.avi', 23, 100, 'None');