function [xmin,ymin,score] = meanShift (current_frameD,xmin,ymin,width,height,target1D)
		width=round(width);
        height=round(height);
		mask = kernel_mask_epane(width, height, 1);
		
		size(current_frameD);
		
		a=ymin-height/2;
		b=ymin+height/2-1;
		c=xmin-width/2;
		d=xmin+width/2-1;	

		%fprintf('%d %d %d %d\n',a,b,c,d);
		
		if (ymin-height/2)<1
			fprintf('top');
			a=1
			b=round(height);
		elseif (xmin-width/2)<1
			fprintf('left');
			c=1
			d=round(width);
		elseif ((ymin+height/2-1)>size(current_frameD,1))
			fprintf('bottom');
			b=round(size(current_frameD,1));
		elseif ((xmin+width/2-1)>size(current_frameD,2))
			fprintf('right');
			d=round(size(current_frameD,2));
		end
		
		%window=current_frameD(ymin-height/2:ymin+height/2-1,xmin-width/2:xmin+width/2-1,1:3);
		window=current_frameD(a:b,c:d,1:3);
		
		size(window);
		size(mask);
			
		[test3D indices]=imageHist2(window,16,mask);
		test1D=reshape(test3D,1,4096);
	
		[ weights ] = computeWeights(target1D,test1D);
		
		score=bat(target1D,test1D);

        for i=1:size(window,2)
            for j=1:size(window,1)
				calWeights(j,i)=weights(indices(j,i));    
            end
        end
        %size(calWeights);
		y0_coords = get_coordinates3(width-1, height-1);
		size(y0_coords);

		y1 = [round(sum(y0_coords(:,:,2) .* calWeights)/sum(calWeights)) round(sum(y0_coords(:,:,1) .* calWeights) / sum(calWeights))];
		xmin=y1(1)/2+xmin;
 		ymin=y1(2)/2+ymin;	
% 		%HACK
% 		xmina=y1(1)+xmin;
% 		ymina=y1(2)+ymin;
% 		a1=ymina-height/2;
% 		b1=ymina+height/2-1;
% 		c1=xmina-width/2;
% 		d1=xmina+width/2-1;
% 		windowa=current_frameD(a1:b1,c1:d1,1:3);
% 		[test3Da indices]=imageHist2(windowa,16,mask);
% 		test1Da=reshape(test3Da,1,4096);
% 		scorea=bat(target1D,test1Da);
% 	
% 		xminb=y1(1)/2+xmin;
% 		yminb=y1(2)/2+ymin;	
% 		a2=yminb-height/2;
% 		b2=yminb+height/2-1;
% 		c2=xminb-width/2;
% 		d2=xminb+width/2-1;
% 		windowb=current_frameD(a2:b2,c2:d2,1:3);
% 		[test3Db indices]=imageHist2(windowb,16,mask);
% 		test1Db=reshape(test3Db,1,4096);
% 		scoreb=bat(target1D,test1Db);
% 		
% 		if(scorea<scoreb)
% 			xmin=xmina;
% 			ymin=ymina;
% 			score=scorea;
% 		else
% 			xmin=xminb;
% 			ymin=yminb;
% 			score=scoreb;
% 		end
end