%Returns the frequencies, input the image and lutsize the number of bins
function [ gamut3D indices ] = imageHist2(originalImage, lutSize,mask )
	%IMAGEHIST Summary of this function goes here
	%   Detailed explanation goes here
	sizeOfImage = size(originalImage);
	reductionFactor = double(256) / double(lutSize);
	gamut3D = zeros(lutSize, lutSize, lutSize);
	lastRow = sizeOfImage(1);
	lastCol = sizeOfImage(2);
    indices=zeros(lastRow,lastCol);
%     indices=cell(lastRow,lastCol,[1 3]);
    k=0;
	for row = 1 : lastRow
		for col = 1: lastCol
			redValue = floor(double(originalImage(row, col, 1)) / reductionFactor) + 1; % Convert from 0-255 to 1-256
			greenValue = floor(double(originalImage(row, col, 2)) / reductionFactor) + 1; % Convert from 0-255 to 1-256
			blueValue = floor(double(originalImage(row, col, 3)) / reductionFactor) + 1; % Convert from 0-255 to 1-256
			%redValue
			%greenValue
			%blueValue
			gamut3D(redValue, greenValue, blueValue) = gamut3D(redValue, greenValue, blueValue)+mask(row,col);
%             tar=gamut3D(redValue, greenValue, blueValue)
            ind=sub2ind(size(gamut3D),redValue,greenValue,blueValue);
% gamut3D=reshape(gamut3D,1,4096);
% pos=find(gamut3D==tar)
% gamut3D=reshape(gamut3D,16,16,16);
            %array of matrix indices
%             indices{row,col}=[redValue, greenValue, blueValue];
 indices(row,col)=ind;
		end
    end
    sum_g=sum(sum(gamut3D(:)));
    %normalize the frequencies
    gamut3D=gamut3D/sum_g;
end

