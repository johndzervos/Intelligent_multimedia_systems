function [xmin,ymin] = brute (current_frameD,xmin,ymin,width,height,target1D,mask)
		k=0;
		%figure('Name','window');
		for i=ymin-(height/2):5:(ymin+height/2)
			for j=xmin-(width/2):5:(xmin+width/2)
				k=k+1;
				
				window=slidingW(current_frameD,round(i),round(j),floor(height/2),floor(width/2));
				
				
				window(:,:,1)=window(:,:,1);%.*mask;
				window(:,:,2)=window(:,:,2);%.*mask;
				window(:,:,3)=window(:,:,3);%.*mask;
				%imshow(window,'InitialMagnification','fit');
				%drawnow;
				
				[ test3D ] = imageHist2(window, 16,mask);
				test1D=reshape(test3D,1,4096);
				
				%euclidean distance target-test
				dist(k,1)=distance(target1D, test1D);
				%dist(k,1)=bhattacharyya(target1D,test1D);
% 				dist(k,1)=bat(target1D,test1D);
				dist(k,2)=i;
				dist(k,3)=j;
			end
		end
		% *your tracking-code here*
		dist;
		asdf=min(dist(:,1));
		ind=find(dist(:,1)==asdf);
		best=dist(ind,:);
		%double(best(1))
		
		%checks so not to take boxes outside the image
		%if(best(1,2)+height>size(first_frame,2) || best(1,3)+width>size(first_frame,1))
			%a=1
		%else
			ymin=best(1,2);
			xmin=best(1,3);
		%end
		
		% if(best(1,1)<90)
			% target3D=test3D;
		% end

end