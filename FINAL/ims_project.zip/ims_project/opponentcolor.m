function im=opponentcolor(s2)
im=s2;
sR=s2(:,:,1);
sG=s2(:,:,2);
sB=s2(:,:,3);

O1=(sR-sG)/sqrt(2);
O2=(sR+sG-(2*sB))/sqrt(6);
O3=(sR+sG+sB)/sqrt(3);

im(:,:,1)=O1;
im(:,:,2)=O2;
im(:,:,3)=O3;