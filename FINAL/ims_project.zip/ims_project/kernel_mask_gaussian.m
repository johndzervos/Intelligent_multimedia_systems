function [ M ] = kernel_mask_gaussian( w, h, sigma )
    % initialise M
    M = zeros(ceil(h), ceil(w));
    
    [X, Y] = ndgrid(-1 : 2/(h-1) : 1, -1 : 2/(w-1) : 1);
    
    M = exp(-(X.^2 + Y.^2)/(2*sigma.^2));
    M = M/sum(sum(M));
end
