function rgb=normrgb(s2)
rgb=s2;
sR=s2(:,:,1);
sG=s2(:,:,2);
sB=s2(:,:,3);
% imshow(sR);
% %pause;
% figure();
% imshow(sG);
% %pause;
% figure();
% imshow(sB);

sumColors=sR+sG+sB;

% for i=1:size(s2,1)
	% for j=1:size(s2,2)
		% if sumColors1(i,j)==0
			% sumColors1(i,j)=0.0001;
		% end
	% end
% end

%a better way to find zero valuus using find
sumReshaped=reshape(sumColors,1,size(s2,1)*size(s2,2));
i=find(~sumReshaped);
sumReshaped(i)=eps;
sumColors=reshape(sumReshaped,size(s2,1),size(s2,2));

normalizedR=sR./sumColors;
normalizedG=sG./sumColors;
normalizedB=sB./sumColors;

rgb(:,:,1)=normalizedR*255;
rgb(:,:,2)=normalizedG*255;
rgb(:,:,3)=normalizedB*255;