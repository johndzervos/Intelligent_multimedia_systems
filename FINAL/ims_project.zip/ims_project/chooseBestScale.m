function [ wid hei ] = chooseBestScale(current_frameD,xmin,ymin,width,height,target1D)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
    scale=0.9;
    results=zeros(3,5);
	for i=1:3
        newWidth=scale*width;
        newHeight=scale*height;
        mask = kernel_mask_epane(newWidth, newHeight, 1);
		size(current_frameD);
		
% 		a=ymin-height/2;
% 		b=ymin+height/2-1;
% 		c=xmin-width/2;
% 		d=xmin+width/2-1;	
% 
% 		%fprintf('%d %d %d %d\n',a,b,c,d);
% 		
% 		if (ymin-height/2)<1
% 			fprintf('top');
% 			a=1
% 			b=height
% 		elseif (xmin-width/2)<1
% 			fprintf('left');
% 			c=1
% 			d=width
% 		elseif ((ymin+height/2-1)>size(current_frameD,1))
% 			fprintf('bottom');
% 			b=size(current_frameD,1)
% 		elseif ((xmin+width/2-1)>size(current_frameD,2))
% 			fprintf('right');
% 			d=size(current_frameD,2)
% 		end
		
		%window=current_frameD(ymin-height/2:ymin+height/2-1,xmin-width/2:xmin+width/2-1,1:3);
		window=current_frameD((ymin-newHeight/2):(ymin+newHeight/2-1),(xmin-newWidth/2):(xmin+newWidth/2-1),1:3);
		
		size(window);
		size(mask);
		
		[test3D indices]=imageHist2(window,16,mask);
		test1D=reshape(test3D,1,4096);
		score=bat(target1D,test1D);
        results(i,:)=[xmin,ymin,score,newWidth,newHeight];
        scale=scale+0.1;
    end
    
    asdf=min(results(:,3));
	ind=find(results(:,3)==asdf);
    ind=ind(1);
	best=results(ind,:);
	wid=best(4);
	hei=best(5);

end

