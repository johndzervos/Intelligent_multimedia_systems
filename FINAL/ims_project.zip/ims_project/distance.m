%when inputs (target, test) have 3 dimensions
function dist=distance(target,test)
	temp=(target-test).^2;
	dist=sqrt(sum(sum(sum(temp))));
end