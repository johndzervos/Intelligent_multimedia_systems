function [ weights ] = computeWeights(histogramTarget,histogramCandid )
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here
weights=zeros(size(histogramTarget));
	for i=1:size(histogramTarget,2)
		
        if histogramCandid(i)==0
            histogramCandid(i)=0.000001;
        end
		weights(i)=sqrt(histogramTarget(i)/histogramCandid(i));
	end
end

