function nbharray=slidingW(image,i,j,N,M)

	[imax, jmax, colormax] = size(image);
	iind=i+(-N:+N);
	jind=j+(-M:+M);
	iind=max(min(iind,imax),1);
	jind=max(min(jind,jmax),1);
	a=size(iind,2);
	b=size(jind,2);
	%start=iind(1)
	%end=iind(a)
	nbharray = image((iind(1)):(iind(a)),(jind(1)):(jind(b)),1:colormax);

end